from flask import Flask, render_template, request
import pandas as pd
from sklearn.neighbors import NearestNeighbors
from scipy.sparse import csr_matrix
import pickle
import requests

app = Flask(__name__, template_folder='templatessss')

# Load your pre-trained models and data
cf_knn_model = pickle.load(open('notebooks/cf_knn_model.pkl', 'rb'))
pivot_table = pickle.load(open('notebooks/pivot_table.pkl', 'rb'))
sparse_matrix = pickle.load(open('notebooks/sparse_matrix.pkl', 'rb'))

cf_knn_model.fit(sparse_matrix)

# Replace with your TMDb API key
TMDB_API_KEY = '1da45a1636f992898447f734b075e56b'
TMDB_IMAGE_URL = 'https://image.tmdb.org/t/p/w500/'

def get_movie_image_and_id(movie_name):
    """Fetch movie poster and ID from TMDb based on the movie name."""
    search_url = f'https://api.themoviedb.org/3/search/movie?api_key={TMDB_API_KEY}&query={movie_name}'
    response = requests.get(search_url)
    data = response.json()
    
    if 'results' in data and data['results']:
        movie = data['results'][0]
        poster_path = movie['poster_path']
        movie_id = movie['id']
        return f"{TMDB_IMAGE_URL}{poster_path}", movie_id
    return None, None

def fetch_movie_details(movie_id):
    """Fetch movie details like genres, overview, trailer URL, director, release date, and popularity from TMDb."""
    details_url = f'https://api.themoviedb.org/3/movie/{movie_id}?api_key={TMDB_API_KEY}&append_to_response=credits'
    response = requests.get(details_url)
    data = response.json()

    genres = [genre['name'] for genre in data.get('genres', [])]
    overview = data.get('overview', 'Overview not available.')
    release_date = data.get('release_date', 'N/A')
    popularity = data.get('popularity', 'N/A')

    # Fetch directors from the credits data
    directors = [crew['name'] for crew in data.get('credits', {}).get('crew', []) if crew['job'] == 'Director']
    director_names = ', '.join(directors) if directors else 'N/A'
    
    videos_url = f'https://api.themoviedb.org/3/movie/{movie_id}/videos?api_key={TMDB_API_KEY}'
    video_response = requests.get(videos_url)
    video_data = video_response.json()

    trailer_url = None
    if 'results' in video_data and video_data['results']:
        trailer_key = video_data['results'][0].get('key')
        if trailer_key:
            trailer_url = f'https://www.youtube.com/watch?v={trailer_key}'
    
    return genres, overview, trailer_url, release_date, popularity, director_names


@app.route('/')
def home():
    movie_list = pivot_table.index.tolist()  # Get list of movies from the pivot table
    return render_template('home.html', movie_list=movie_list)

@app.route('/result', methods=['POST'])
def result():
    selected_movie = request.form.get('movie_name')
    n_neighbors = int(request.form.get('n_neighbors', 4))  # Get number of neighbors from the form (default to 6)
    recommendations = get_recommendations(selected_movie, n_neighbors)
    return render_template('result.html', selected_movie=selected_movie, recommendations=recommendations)

def get_recommendations(selected_movie, n_neighbors=6):
    """Returns a list of movie recommendations based on the selected movie and number of neighbors."""
    recommendations = []

    # Normalize input and check if movie exists (case insensitive)
    selected_movie = selected_movie.strip()
    if selected_movie.lower() not in [title.lower() for title in pivot_table.index]:
        return [("Movie not found.", "N/A", None, [], "N/A", None, "N/A", "N/A", "N/A", "N/A")]

    selected_movie_id = pivot_table.index.get_loc(selected_movie)
    input_data = pivot_table.iloc[selected_movie_id, :].values.reshape(1, -1)

    # Check if the input data is valid
    if not any(input_data.flatten()):
        return [("No recommendations available.", "N/A", None, [], "N/A", None, "N/A", "N/A", "N/A", "N/A")]

    distances, indices = cf_knn_model.kneighbors(input_data, n_neighbors=n_neighbors)

    for i in range(1, len(distances.flatten())):
        movie_title = pivot_table.index[indices.flatten()[i]]
        distance = distances.flatten()[i]
        
        # Fetch the movie poster and correct TMDb ID
        movie_image, tmdb_movie_id = get_movie_image_and_id(movie_title)

        if tmdb_movie_id:  # Only fetch details if a valid TMDb ID was found
            genres, overview, trailer_url, release_date, popularity, director_names = fetch_movie_details(tmdb_movie_id)
        else:
            genres, overview, trailer_url, release_date, popularity, director_names = [], "Details not available.", None, "N/A", "N/A", "N/A"

        # Scale rating (as per previous logic) and round to one decimal place
        avg_rating = (pivot_table.loc[movie_title].mean() * 10)

        recommendations.append((
            movie_title, 
            round(float(distance), 2), 
            movie_image, 
            genres, 
            overview, 
             round(avg_rating, 1), 
            trailer_url,
            release_date, 
            popularity, 
            director_names
        ))

    return recommendations

if __name__ == '__main__':
    app.run(debug=True)
